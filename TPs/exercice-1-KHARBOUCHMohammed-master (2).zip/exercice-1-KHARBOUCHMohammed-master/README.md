# CERI - Avignon Université - L3 - UE Design Patterns

## Exercice 1


Pour créer votre fork, acceptez l'affectation sur GitHub Classroom https://classroom.github.com/a/Q6cQuoyC

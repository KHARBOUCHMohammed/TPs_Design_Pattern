public class Personne {


    private String nom;
    private String prenom;




    protected Personne()
    {
    }
}

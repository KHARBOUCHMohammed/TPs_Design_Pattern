public class EnseiRep extends Enseignant {


    public static Enseignant representant;


    public static Enseignant getRep(){

        return representant;
    }


    public static void setRepresentant(Enseignant representant) {
        EtudiantRep.representant = representant;
    }
}

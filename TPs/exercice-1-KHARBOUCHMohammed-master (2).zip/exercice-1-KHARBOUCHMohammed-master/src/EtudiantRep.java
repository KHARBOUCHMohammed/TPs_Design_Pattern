public class EtudiantRep  {


    public static Enseignant representant;

    private  static Etudiant represantant   ;

    public static Etudiant getRep(){

        return represantant;
    }


    public static void setRepresantant(Etudiant represantant) {
        EtudiantRep.represantant = represantant;
    }
}



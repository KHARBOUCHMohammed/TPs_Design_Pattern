import java.util.HashMap;

public class Represantant {

    private  static Personne represantant ;
    private static HashMap<String, Represantant> registre = new HashMap<String, Represantant>();

    protected static Represantant getName(String name) {
        return registre.get(name);
    }
    public static Personne represantant() {

        return represantant;
    }

    public static void setRepresantant(Personne represantant) {
        EtudiantRep.setRepresantant(represantant);
    }


}

public class Enseignant extends Personne{
   /* private String nom;
    private String prenom;

    protected Enseignant()
    {
    }*/


}

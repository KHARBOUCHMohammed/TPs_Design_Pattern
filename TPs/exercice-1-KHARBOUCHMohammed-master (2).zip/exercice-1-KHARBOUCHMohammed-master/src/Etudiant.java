class Etudiant extends Personne{
   /* private String nom;
    private String prenom;




    protected Etudiant()
    {
    }

*/
}

# CERI - Avignon Université - L3 - UE Design Patterns

## Exercice 5

Pour créer votre fork, acceptez l'affectation sur GitHub Classroom https://classroom.github.com/a/qXrSpnMv


public interface IConnectable {
	void demarrer();
	public void calculer();
}

public interface IRepartitionConsommation {
	// A completer
}


public enum Mode {
    VEILLE, NORMAL, HAUT
}

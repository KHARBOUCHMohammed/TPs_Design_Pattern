
public interface IConsommable {
	int getDureeConnexion();
	int getPuissance();
	Mode getMode();
	void setDureeConnexion(int d);
	void setPuissance(int p);
	void setMode(Mode m);
	// A completer
}

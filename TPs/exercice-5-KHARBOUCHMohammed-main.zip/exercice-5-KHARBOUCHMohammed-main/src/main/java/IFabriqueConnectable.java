
public interface IFabriqueConnectable {
	IConnectable creer(String nomClasse);
}

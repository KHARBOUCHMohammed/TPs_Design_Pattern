import java.util.Scanner;

public class PourcentagePuissance implements IConnectable {
    @Override
    public void demarrer() {

    }


    float tempsTotal;

    @Override
    public void calculer() {

        float Dtotal = 60;
        Scanner sc = new Scanner(System.in);
        System.out.println("Donner le temps pendant est activé  : " );
        float tempsConsomme=sc.nextFloat();
        float pourcentagetemps;
        pourcentagetemps= tempsConsomme*100/Dtotal;
        System.out.println("le pourcentage du temps consommé est : "+pourcentagetemps+ "%");



    }

}

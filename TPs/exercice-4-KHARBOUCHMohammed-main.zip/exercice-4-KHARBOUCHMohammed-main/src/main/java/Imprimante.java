
public class Imprimante  {


	public void imprimer() {
		System.out.println("L'imprimante " + this + " imprime");
	}

}

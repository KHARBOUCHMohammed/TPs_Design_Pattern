
public interface IConnectable {
	void demarrer();
}
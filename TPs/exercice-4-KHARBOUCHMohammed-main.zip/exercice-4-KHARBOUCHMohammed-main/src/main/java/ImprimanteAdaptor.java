public class ImprimanteAdaptor extends Imprimante implements IConnectable {
    private Imprimante imprimante = new Imprimante();

    @Override
    public void demarrer() {
        imprimante.imprimer();
    }
}

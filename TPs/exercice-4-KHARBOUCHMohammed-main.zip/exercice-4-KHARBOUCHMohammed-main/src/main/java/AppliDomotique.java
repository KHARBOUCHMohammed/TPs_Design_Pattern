import java.util.ArrayList;

public abstract  class AppliDomotique implements IConnectable {
	
	static ArrayList<IConnectable> lesConnectes = new ArrayList<IConnectable>();

	public void demarrer(String nomClasse){
		for ( IConnectable elem : lesConnectes)
			if (lesConnectes.toString() ==nomClasse )
				elem.demarrer();
	}

		public static void main(String[] args) {
		// A completer
		ImprimanteAdaptor imprimante =new ImprimanteAdaptor();
		imprimante.demarrer();
	}





}

# CERI - Avignon Université - L3 - UE Design Patterns

## Exercice 4

Pour créer votre fork, acceptez l'affectation sur GitHub Classroom https://classroom.github.com/a/1TFiwkY8

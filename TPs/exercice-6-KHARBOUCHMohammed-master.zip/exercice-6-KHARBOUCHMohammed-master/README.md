# CERI - Avignon Université - L3 - UE Design Patterns

## Exercice 6


Pour créer votre fork, acceptez l'affectation sur GitHub Classroom https://classroom.github.com/a/XJNWGfdl

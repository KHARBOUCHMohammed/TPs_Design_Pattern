
public interface IFabriqueConnectable {
	public IConnectable creer(String nomClasse);
}

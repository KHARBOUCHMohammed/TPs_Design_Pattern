
public interface IConnectable {
	// A completer
    public void demarrer(IConnectable obj);
}

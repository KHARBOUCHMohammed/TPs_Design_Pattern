
public class Radio implements IConnectable {
	// A completer

    @Override
    public void demarrer(IConnectable obj) {
        System.out.println("La radio "+obj+" est démarré");
    }
}

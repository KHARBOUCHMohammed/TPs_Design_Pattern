abstract class AbDemarreur {

        public abstract void activer(IConnectable obj);
        public abstract void detacher(IConnectable obj);
        public abstract void notifier();
}

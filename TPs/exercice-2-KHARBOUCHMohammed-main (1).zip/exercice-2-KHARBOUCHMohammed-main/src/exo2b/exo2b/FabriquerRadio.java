package exo2b;

public class FabriquerRadio implements IFabriquerConnectable {

    @Override
    public IConnectable creationConnectable() {
        return new Radio();
    }
}

package exo2b;

public class  Cafitiere implements IConnectable {
}

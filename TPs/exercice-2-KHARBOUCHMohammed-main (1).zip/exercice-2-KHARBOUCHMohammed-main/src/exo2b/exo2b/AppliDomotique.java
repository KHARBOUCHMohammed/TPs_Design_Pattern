package exo2b;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class AppliDomotique  {
	
	static ArrayList<IConnectable> lesConnectes=new ArrayList<IConnectable>();
	//private static java.lang.Object Object;

	public static String saisieNomClasse() {
		String nomClasse = new String();
		System.out.println("Taper Entr�e pour finir ou le nom de la classe de l'objet � connecter");
		BufferedReader in=new BufferedReader(new InputStreamReader( System.in ));
		try {
			nomClasse = in.readLine();
		}
		catch (IOException e) {}
		return nomClasse;
	}
	
	public static void connecter(String nomClasse) {
		// A compl�ter

		IFabriquerConnectable fabriquer = null;
		switch(nomClasse) {
			case("Cafetiere"):
				fabriquer = new FabriquerCafitiere();
				lesConnectes.add(fabriquer.creationConnectable());

			case("Radio"):
				fabriquer = new FabriquerRadio();
				lesConnectes.add(fabriquer.creationConnectable());
			default:
				Object objet = fabriquer.creationConnectable();
				lesConnectes.add(Object);
		}

	}



}
	
	public static void main(String[] args) {
		String classeEffective;
		while (!(classeEffective = saisieNomClasse()).isEmpty()){
			connecter(classeEffective);
		}
		System.out.println(lesConnectes);
	}

}

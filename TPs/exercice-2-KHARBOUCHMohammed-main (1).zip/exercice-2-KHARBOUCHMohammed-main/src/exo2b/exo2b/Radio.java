package exo2b;

public class Radio implements  IConnectable {
}

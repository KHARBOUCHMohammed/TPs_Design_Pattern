package exo2b;

public class FabriquerCafitiere implements IFabriquerConnectable{
    @Override
    public IConnectable creationConnectable() {
        return new Cafitiere();
    }
}

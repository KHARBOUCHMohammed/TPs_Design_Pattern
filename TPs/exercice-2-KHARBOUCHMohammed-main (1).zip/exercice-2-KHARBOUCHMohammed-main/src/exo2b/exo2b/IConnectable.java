package exo2b;

public interface  IConnectable {
}

package exo2b;

public interface IFabriquerConnectable {
    // A compléter

    IConnectable creationConnectable();
}

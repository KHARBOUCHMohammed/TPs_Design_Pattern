public class Radio implements IConnectable {
}

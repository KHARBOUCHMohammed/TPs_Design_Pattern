public class Cafetiere implements IConnectable {
}

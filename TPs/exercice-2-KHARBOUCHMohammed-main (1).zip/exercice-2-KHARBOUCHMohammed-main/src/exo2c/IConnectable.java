public interface IConnectable {
}

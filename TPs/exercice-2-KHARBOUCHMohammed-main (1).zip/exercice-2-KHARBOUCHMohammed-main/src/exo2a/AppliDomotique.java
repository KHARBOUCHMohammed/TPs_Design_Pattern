package exo2a;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map;

public class AppliDomotique {
	ArrayList<String> sort = new ArrayList<String>();
	public static int saisieNomClasse() {
		int choix = 1;
		System.out.println("Taper 0 pour finir, 1 pour connecter une cafeti�re et 2 pour une radio");
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		try {
			choix = Integer.parseInt(in.readLine());
		}
		catch (IOException e) {}
		return choix;
	}

	public static <Cafitiere, Radio> void connecter(int type) {
		// A compl�ter
		ArrayList<Object> sort = new ArrayList<Object>();
		if(type == 1)
			{
				Cafitiere cafitiere = new Cafitiere();
				sort.add(cafitiere);
			}
		else if(type == 2)
			{
				Radio radio = new Radio();
				sort.add(radio);
			}
		else if (type == 0)
			{
				sort.add(0);
			}

	}
	
	public static void main(String[] args) {
		int type = 0;
		while ((type = saisieNomClasse()) != 0){
			// A compl�ter
			connecter( type);
		}
		// A compl�ter pour afficher les �l�ments connect�s
		

		}
	}

}

public interface IConnecter extends IAppliDomotique {
    public void affich();
}

public interface IAppliDomotique  {
}

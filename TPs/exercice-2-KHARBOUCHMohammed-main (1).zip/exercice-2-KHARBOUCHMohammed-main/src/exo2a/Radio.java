public class Radio implements IConnecter {

   /* private int id;

    public Radio(int id){
        this.id = id;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }*/
    @Override
    public void affich()  {

    }
}

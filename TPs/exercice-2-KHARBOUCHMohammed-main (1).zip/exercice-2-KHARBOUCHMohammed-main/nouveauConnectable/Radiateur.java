public class Radiateur implements IConnectable {
}

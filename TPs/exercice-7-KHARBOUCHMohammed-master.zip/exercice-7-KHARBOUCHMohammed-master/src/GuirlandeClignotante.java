
public class GuirlandeClignotante {

	private ThreadClignotement thread;

/*	@Override
	public void demarrer() {
		if (!thread.isAlive()) {
			thread.start();
		}
		inner.demarrer();
	}*/

}

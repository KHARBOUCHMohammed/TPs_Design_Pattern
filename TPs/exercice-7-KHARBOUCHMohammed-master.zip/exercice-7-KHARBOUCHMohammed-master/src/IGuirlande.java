
public interface IGuirlande {

	public void demarrer();
	public void arret ();
	public void setCouleur(boolean rouge, boolean vert, boolean bleu);

}

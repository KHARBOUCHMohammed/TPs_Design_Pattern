
public interface IConnectable {
	public void demarrer();
}

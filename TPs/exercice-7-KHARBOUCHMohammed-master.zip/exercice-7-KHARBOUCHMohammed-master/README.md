# CERI - Avignon Université - L3 - UE Design Patterns

## Exercice 7

Pour créer votre fork, acceptez l'affectation sur GitHub Classroom https://classroom.github.com/a/nNkOdEuo
